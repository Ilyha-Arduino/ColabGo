const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = 3001;
const DATA_FILE = path.join(__dirname, 'data', 'database.json');

// Middleware
app.use(cors());
app.use(express.json());

// Создаем папку data и файл database.json если их нет
async function initializeDataFile() {
  try {
    const dataDir = path.join(__dirname, 'data');
    
    // Создаем папку data если ее нет
    try {
      await fs.access(dataDir);
    } catch {
      await fs.mkdir(dataDir);
    }
    
    // Создаем файл database.json если его нет
    try {
      await fs.access(DATA_FILE);
    } catch {
      const initialData = {
        users: [
          {
            "id": 1,
            "username": "alex_prog",
            "password": "pass123",
            "email": "alex@example.com",
            "fullName": "Алексей Программистов",
            "userType": "Программист",
            "interests": ["Дизайнер", "Маркетолог"],
            "bio": "Full-stack разработчик, ищу дизайнера для создания мобильного приложения",
            "skills": ["JavaScript", "React", "Node.js"],
            "likedUsers": [],
            "dislikedUsers": [],
            "matches": []
          },
          {
            "id": 2,
            "username": "anna_design",
            "password": "pass123",
            "email": "anna@example.com",
            "fullName": "Анна Дизайнерова",
            "userType": "Дизайнер",
            "interests": ["Программист", "Менеджер"],
            "bio": "UI/UX дизайнер с опытом в мобильных приложениях",
            "skills": ["Figma", "Photoshop", "Illustrator"],
            "likedUsers": [],
            "dislikedUsers": [],
            "matches": []
          }
        ],
        currentUser: null
      };
      await fs.writeFile(DATA_FILE, JSON.stringify(initialData, null, 2));
      console.log('Файл database.json создан с начальными данными');
    }
  } catch (error) {
    console.error('Ошибка инициализации файла данных:', error);
  }
}

// Чтение данных из файла
async function readData() {
  try {
    const data = await fs.readFile(DATA_FILE, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Ошибка чтения файла:', error);
    return { users: [], currentUser: null };
  }
}

// Запись данных в файл
async function writeData(data) {
  try {
    await fs.writeFile(DATA_FILE, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('Ошибка записи в файл:', error);
    return false;
  }
}

// API маршруты

// Получить все данные
app.get('/api/data', async (req, res) => {
  try {
    const data = await readData();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка чтения данных' });
  }
});

// Получить текущего пользователя
app.get('/api/current-user', async (req, res) => {
  try {
    const data = await readData();
    res.json(data.currentUser);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка чтения данных' });
  }
});

// Войти в систему
app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const data = await readData();
    
    const user = data.users.find(u => u.username === username && u.password === password);
    
    if (user) {
      data.currentUser = user;
      await writeData(data);
      res.json({ success: true, user });
    } else {
      res.json({ success: false, error: 'Неверный логин или пароль' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: 'Ошибка входа' });
  }
});

// Зарегистрироваться
app.post('/api/register', async (req, res) => {
  try {
    const { username, password, email, fullName } = req.body;
    const data = await readData();
    
    // Проверка уникальности логина
    if (data.users.some(u => u.username === username)) {
      return res.json({ success: false, error: 'Пользователь с таким логином уже существует' });
    }
    
    // Проверка уникальности email
    if (data.users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
      return res.json({ success: false, error: 'Пользователь с таким email уже существует' });
    }
    
    // Создание нового пользователя
    const newUser = {
      id: data.users.length > 0 ? Math.max(...data.users.map(u => u.id)) + 1 : 1,
      username,
      password,
      email,
      fullName,
      userType: '',
      interests: [],
      bio: '',
      skills: [],
      likedUsers: [],
      dislikedUsers: [],
      matches: []
    };
    
    data.users.push(newUser);
    data.currentUser = newUser;
    
    await writeData(data);
    
    res.json({ success: true, user: newUser });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Ошибка регистрации' });
  }
});

// Выйти из системы
app.post('/api/logout', async (req, res) => {
  try {
    const data = await readData();
    data.currentUser = null;
    await writeData(data);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Ошибка выхода' });
  }
});

// Обновить профиль
app.put('/api/update-profile/:userId', async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const updatedData = req.body;
    const data = await readData();
    
    const userIndex = data.users.findIndex(u => u.id === userId);
    
    if (userIndex !== -1) {
      // Сохраняем пароль отдельно, чтобы не перезаписать его
      const currentPassword = data.users[userIndex].password;
      data.users[userIndex] = { ...data.users[userIndex], ...updatedData, password: currentPassword };
      
      // Обновляем текущего пользователя если нужно
      if (data.currentUser && data.currentUser.id === userId) {
        data.currentUser = data.users[userIndex];
      }
      
      await writeData(data);
      res.json({ success: true, user: data.users[userIndex] });
    } else {
      res.json({ success: false, error: 'Пользователь не найден' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: 'Ошибка обновления профиля' });
  }
});

// Сменить пароль
app.post('/api/change-password/:userId', async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const { currentPassword, newPassword } = req.body;
    const data = await readData();
    
    const userIndex = data.users.findIndex(u => u.id === userId);
    
    if (userIndex !== -1 && data.users[userIndex].password === currentPassword) {
      data.users[userIndex].password = newPassword;
      
      // Обновляем текущего пользователя если нужно
      if (data.currentUser && data.currentUser.id === userId) {
        data.currentUser = data.users[userIndex];
      }
      
      await writeData(data);
      res.json({ success: true });
    } else {
      res.json({ success: false, error: 'Текущий пароль неверен' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: 'Ошибка смены пароля' });
  }
});

// Получить рекомендации
app.get('/api/recommendations/:userId', async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const data = await readData();
    const currentUser = data.users.find(u => u.id === userId);
    
    if (!currentUser) {
      return res.json([]);
    }
    
    // Фильтруем пользователей
    let recommendedUsers = data.users.filter(user => 
      user.id !== userId &&
      !currentUser.likedUsers.includes(user.id) &&
      !currentUser.dislikedUsers.includes(user.id)
    );
    
    // Если есть интересы, фильтруем по ним
    if (currentUser.interests && currentUser.interests.length > 0) {
      recommendedUsers = recommendedUsers.filter(user => 
        currentUser.interests.includes(user.userType)
      );
    }
    
    res.json(recommendedUsers);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка получения рекомендаций' });
  }
});

// Лайк пользователя
app.post('/api/like/:currentUserId/:targetUserId', async (req, res) => {
  try {
    const currentUserId = parseInt(req.params.currentUserId);
    const targetUserId = parseInt(req.params.targetUserId);
    const data = await readData();
    
    const currentUserIndex = data.users.findIndex(u => u.id === currentUserId);
    const targetUser = data.users.find(u => u.id === targetUserId);
    
    if (currentUserIndex !== -1 && targetUser) {
      // Добавляем лайк
      if (!data.users[currentUserIndex].likedUsers.includes(targetUserId)) {
        data.users[currentUserIndex].likedUsers.push(targetUserId);
      }
      
      // Проверяем взаимный лайк
      if (targetUser.likedUsers.includes(currentUserId)) {
        if (!data.users[currentUserIndex].matches.includes(targetUserId)) {
          data.users[currentUserIndex].matches.push(targetUserId);
        }
        
        const targetUserIndex = data.users.findIndex(u => u.id === targetUserId);
        if (!data.users[targetUserIndex].matches.includes(currentUserId)) {
          data.users[targetUserIndex].matches.push(currentUserId);
        }
      }
      
      // Обновляем текущего пользователя
      if (data.currentUser && data.currentUser.id === currentUserId) {
        data.currentUser = data.users[currentUserIndex];
      }
      
      await writeData(data);
      res.json({ success: true });
    } else {
      res.json({ success: false, error: 'Пользователь не найден' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: 'Ошибка' });
  }
});

// Дизлайк пользователя
app.post('/api/dislike/:currentUserId/:targetUserId', async (req, res) => {
  try {
    const currentUserId = parseInt(req.params.currentUserId);
    const targetUserId = parseInt(req.params.targetUserId);
    const data = await readData();
    
    const currentUserIndex = data.users.findIndex(u => u.id === currentUserId);
    
    if (currentUserIndex !== -1) {
      // Добавляем дизлайк
      if (!data.users[currentUserIndex].dislikedUsers.includes(targetUserId)) {
        data.users[currentUserIndex].dislikedUsers.push(targetUserId);
      }
      
      // Обновляем текущего пользователя
      if (data.currentUser && data.currentUser.id === currentUserId) {
        data.currentUser = data.users[currentUserIndex];
      }
      
      await writeData(data);
      res.json({ success: true });
    } else {
      res.json({ success: false, error: 'Пользователь не найден' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: 'Ошибка' });
  }
});

// Получить принятых пользователей
app.get('/api/liked/:userId', async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const data = await readData();
    const currentUser = data.users.find(u => u.id === userId);
    
    if (!currentUser) return res.json([]);
    
    const likedUsers = data.users.filter(u => currentUser.likedUsers.includes(u.id));
    res.json(likedUsers);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка' });
  }
});

// Получить отклоненных пользователей
app.get('/api/disliked/:userId', async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const data = await readData();
    const currentUser = data.users.find(u => u.id === userId);
    
    if (!currentUser) return res.json([]);
    
    const dislikedUsers = data.users.filter(u => currentUser.dislikedUsers.includes(u.id));
    res.json(dislikedUsers);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка' });
  }
});

// Получить матчи
app.get('/api/matches/:userId', async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const data = await readData();
    const currentUser = data.users.find(u => u.id === userId);
    
    if (!currentUser) return res.json([]);
    
    const matches = data.users.filter(u => currentUser.matches.includes(u.id));
    res.json(matches);
  } catch (error) {
    res.status(500).json({ error: 'Ошибка' });
  }
});

// Запуск сервера
async function startServer() {
  await initializeDataFile();
  
  app.listen(PORT, () => {
    console.log(`Сервер запущен на http://localhost:${PORT}`);
    console.log(`Данные хранятся в файле: ${DATA_FILE}`);
    console.log('API доступны:');
    console.log('  GET  /api/data - все данные');
    console.log('  POST /api/login - вход');
    console.log('  POST /api/register - регистрация');
    console.log('  GET  /api/recommendations/:userId - рекомендации');
  });
}

startServer();