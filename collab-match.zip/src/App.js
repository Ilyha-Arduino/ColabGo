import React, { useState, useEffect } from 'react';
import './App.css';
import Header from './components/Header';
import Footer from './components/Footer';
import LoginForm from './components/LoginForm';
import ProfileForm from './components/ProfileForm';
import UserCard from './components/UserCard';
import Tabs from './components/Tabs';
// Импортируем сервис под правильным именем
import ApiService from './utils/dataService';

function App() {
  // Состояния приложения
  const [currentUser, setCurrentUser] = useState(null);
  const [recommendedUsers, setRecommendedUsers] = useState([]);
  const [likedUsers, setLikedUsers] = useState([]);
  const [dislikedUsers, setDislikedUsers] = useState([]);
  const [matchedUsers, setMatchedUsers] = useState([]);
  const [currentView, setCurrentView] = useState('login'); // login, profile, match
  const [activeTab, setActiveTab] = useState('match'); // match, matches, liked, disliked
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  // Загрузка данных при запуске приложения
  useEffect(() => {
    const initApp = async () => {
      try {
        // Загружаем текущего пользователя из данных
        const user = await ApiService.getCurrentUser();
        
        if (user) {
          // Если пользователь найден, устанавливаем его
          setCurrentUser(user);
          
          // Проверяем, заполнен ли профиль
          if (user.userType && user.interests.length > 0) {
            // Если профиль заполнен, загружаем все данные и переходим в режим знакомств
            await loadAllUserData(user.id);
            setCurrentView('match');
          } else {
            // Если профиль не заполнен, переходим к заполнению профиля
            setCurrentView('profile');
          }
        } else {
          // Если пользователь не найден, остаемся на странице входа
          setCurrentView('login');
        }
      } catch (err) {
        console.error('Ошибка инициализации приложения:', err);
        setError('Ошибка загрузки данных. Пожалуйста, перезагрузите страницу.');
      } finally {
        setLoading(false);
      }
    };
    
    initApp();
  }, []);
  
  // Загрузка всех данных пользователя
  const loadAllUserData = async (userId) => {
    try {
      // Загружаем рекомендации
      const recommended = await ApiService.getRecommendedUsers(userId);
      setRecommendedUsers(recommended);
      
      // Загружаем принятых пользователей
      const liked = await ApiService.getLikedUsers(userId);
      setLikedUsers(liked);
      
      // Загружаем отклоненных пользователей
      const disliked = await ApiService.getDislikedUsers(userId);
      setDislikedUsers(disliked);
      
      // Загружаем матчи
      const matches = await ApiService.getMatches(userId);
      setMatchedUsers(matches);
    } catch (err) {
      console.error('Ошибка загрузки данных пользователя:', err);
    }
  };
  
  // Обработчик входа
  const handleLogin = async (username, password) => {
    try {
      // Ищем пользователя с таким логином и паролем
      const user = await ApiService.login(username, password);
      
      // Устанавливаем пользователя как текущего
      setCurrentUser(user);
      setError('');
      
      // Проверяем, заполнен ли профиль
      if (user.userType && user.interests.length > 0) {
        // Если профиль заполнен, загружаем все данные
        await loadAllUserData(user.id);
        setCurrentView('match');
      } else {
        // Если профиль не заполнен, переходим к заполнению
        setCurrentView('profile');
      }
    } catch (err) {
      console.error('Ошибка входа:', err.message);
      setError(err.message || 'Ошибка входа. Попробуйте еще раз.');
    }
  };
  
  // Обработчик регистрации
  const handleRegister = async (userData) => {
    try {
      // Проверяем, существует ли пользователь с таким логином
      const usernameExists = await ApiService.usernameExists(userData.username);
      
      if (usernameExists) {
        setError('Пользователь с таким логином уже существует');
        return;
      }
      
      // Проверяем, существует ли пользователь с таким email
      const emailExists = await ApiService.emailExists(userData.email);
      
      if (emailExists) {
        setError('Пользователь с таким email уже существует');
        return;
      }
      
      // Создаем нового пользователя
      const newUser = await ApiService.register(userData);
      
      // Устанавливаем нового пользователя как текущего
      setCurrentUser(newUser);
      setError('');
      
      // Переходим к заполнению профиля
      setCurrentView('profile');
    } catch (err) {
      console.error('Ошибка регистрации:', err.message);
      setError(err.message || 'Ошибка регистрации. Попробуйте еще раз.');
    }
  };
  
  // Обработчик сохранения профиля
  const handleSaveProfile = async (profileData) => {
    try {
      // Обновляем профиль пользователя
      const updatedUser = await ApiService.updateUser(currentUser.id, profileData);
      
      // Обновляем текущего пользователя
      setCurrentUser(updatedUser);
      
      // Загружаем все данные
      await loadAllUserData(updatedUser.id);
      
      // Переходим к режиму знакомств
      setCurrentView('match');
    } catch (err) {
      console.error('Ошибка сохранения профиля:', err.message);
      setError(err.message || 'Ошибка сохранения профиля. Попробуйте еще раз.');
    }
  };
  
  // Обработчик смены пароля
  const handleChangePassword = async (currentPassword, newPassword) => {
    try {
      const success = await ApiService.changePassword(
        currentUser.id, 
        currentPassword, 
        newPassword
      );
      
      if (success) {
        alert('Пароль успешно изменен!');
      } else {
        alert('Текущий пароль неверен!');
      }
    } catch (err) {
      console.error('Ошибка смены пароля:', err.message);
      alert('Ошибка смены пароля. Попробуйте еще раз.');
    }
  };
  
  // Обработчик принятия пользователя (лайк)
  const handleAcceptUser = async (userId) => {
    try {
      // Добавляем пользователя в лайкнутые
      await ApiService.likeUser(currentUser.id, userId);
      
      // Обновляем все данные
      await loadAllUserData(currentUser.id);
      
      // Показываем сообщение об успехе
      const acceptedUser = recommendedUsers.find(u => u.id === userId);
      if (acceptedUser) {
        alert(`Вы приняли пользователя ${acceptedUser.fullName}!`);
      }
    } catch (err) {
      console.error('Ошибка принятия пользователя:', err);
    }
  };
  
  // Обработчик отклонения пользователя (дизлайк)
  const handleRejectUser = async (userId) => {
    try {
      // Добавляем пользователя в дизлайкнутые
      await ApiService.dislikeUser(currentUser.id, userId);
      
      // Обновляем все данные
      await loadAllUserData(currentUser.id);
    } catch (err) {
      console.error('Ошибка отклонения пользователя:', err);
    }
  };
  
  // Обработчик выхода
  const handleLogout = async () => {
    try {
      // Выход из системы
      await ApiService.logout();
      setCurrentUser(null);
      setCurrentView('login');
      setRecommendedUsers([]);
      setLikedUsers([]);
      setDislikedUsers([]);
      setMatchedUsers([]);
    } catch (err) {
      console.error('Ошибка выхода:', err);
    }
  };
  
  // Обработчик перехода к редактированию профиля
  const handleEditProfile = () => {
    setCurrentView('editProfile');
  };
  
  // Обработчик возврата к знакомствам
  const handleBackToMatch = () => {
    setCurrentView('match');
  };
  
  // Функция для рендеринга контента в зависимости от активной вкладки
  const renderTabContent = () => {
    switch (activeTab) {
      case 'match':
        return (
          <div className="match-results">
            <p>Найдено {recommendedUsers.length} человек для знакомства:</p>
            
            {recommendedUsers.length > 0 ? (
              <div className="user-cards-container">
                {recommendedUsers.map(user => (
                  <UserCard 
                    key={user.id} 
                    user={user} 
                    onAccept={handleAcceptUser} 
                    onReject={handleRejectUser} 
                    showActions={true}
                  />
                ))}
              </div>
            ) : (
              <div className="no-results">
                <h3>Пока нет новых рекомендаций</h3>
                <p>Попробуйте изменить критерии поиска в настройках профиля или зайдите позже.</p>
                <button onClick={handleEditProfile} className="edit-profile-btn">
                  Изменить настройки профиля
                </button>
              </div>
            )}
          </div>
        );
        
      case 'matches':
        return (
          <div className="matches-results">
            <h3>Ваши матчи ({matchedUsers.length})</h3>
            <p>Это пользователи, которые также приняли вас. Можете начинать общение!</p>
            
            {matchedUsers.length > 0 ? (
              <div className="user-cards-container">
                {matchedUsers.map(user => (
                  <UserCard 
                    key={user.id} 
                    user={user} 
                    onAccept={() => {}} 
                    onReject={() => {}} 
                    showActions={false}
                  />
                ))}
              </div>
            ) : (
              <div className="no-results">
                <h3>У вас пока нет матчей</h3>
                <p>Продолжайте знакомиться с пользователями, и когда кто-то тоже примет вас - здесь появится матч!</p>
              </div>
            )}
          </div>
        );
        
      case 'liked':
        return (
          <div className="liked-results">
            <h3>Принятые вами пользователи ({likedUsers.length})</h3>
            <p>Это пользователи, которых вы приняли. Ждем взаимности!</p>
            
            {likedUsers.length > 0 ? (
              <div className="user-cards-container">
                {likedUsers.map(user => (
                  <UserCard 
                    key={user.id} 
                    user={user} 
                    onAccept={() => {}} 
                    onReject={() => {}} 
                    showActions={false}
                  />
                ))}
              </div>
            ) : (
              <div className="no-results">
                <h3>Вы еще никого не приняли</h3>
                <p>Начните знакомиться с пользователями на вкладке "Знакомства"</p>
              </div>
            )}
          </div>
        );
        
      case 'disliked':
        return (
          <div className="disliked-results">
            <h3>Отклоненные вами пользователи ({dislikedUsers.length})</h3>
            <p>Это пользователи, которых вы отклонили.</p>
            
            {dislikedUsers.length > 0 ? (
              <div className="user-cards-container">
                {dislikedUsers.map(user => (
                  <UserCard 
                    key={user.id} 
                    user={user} 
                    onAccept={() => {}} 
                    onReject={() => {}} 
                    showActions={false}
                  />
                ))}
              </div>
            ) : (
              <div className="no-results">
                <h3>Вы еще никого не отклонили</h3>
                <p>Все предложенные пользователи вам нравятся? Это отлично!</p>
              </div>
            )}
          </div>
        );
        
      default:
        return null;
    }
  };
  
  // Если приложение загружается
  if (loading) {
    return (
      <div className="app loading">
        <div className="container">
          <h2>Загрузка приложения...</h2>
          <div className="loader"></div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="app">
      <Header currentUser={currentUser} onLogout={handleLogout} />
      
      <main className="main-content">
        <div className="container">
          {/* Страница входа/регистрации */}
          {currentView === 'login' && (
            <div className="login-page">
              <div className="welcome-message">
                <h2>Добро пожаловать в CollabMatch!</h2>
                <p>Сервис для объединения учащихся разных направлений: программистов, дизайнеров, инженеров, математиков и других специалистов.</p>
                <p>Находите команду для своих проектов, делитесь знаниями и создавайте крутые коллаборации!</p>
              </div>
              <LoginForm 
                onLogin={handleLogin} 
                onRegister={handleRegister} 
                error={error} 
              />
            </div>
          )}
          
          {/* Страница заполнения профиля */}
          {currentView === 'profile' && (
            <div className="profile-setup-page">
              <h2>Заполните ваш профиль</h2>
              <p>Расскажите о себе, чтобы мы могли подобрать для вас подходящих людей для коллаборации.</p>
              <ProfileForm 
                user={currentUser} 
                onSave={handleSaveProfile} 
                onChangePassword={handleChangePassword} 
              />
            </div>
          )}
          
          {/* Страница знакомств и других разделов */}
          {currentView === 'match' && (
            <div className="match-page">
              <div className="page-header">
                <h2>Найдите команду для ваших проектов</h2>
                <button onClick={handleEditProfile} className="edit-profile-btn">
                  Редактировать профиль
                </button>
              </div>
              
              {/* Вкладки для переключения между разделами */}
              <Tabs activeTab={activeTab} onTabChange={setActiveTab} />
              
              {/* Контент в зависимости от активной вкладки */}
              {renderTabContent()}
            </div>
          )}
          
          {/* Страница редактирования профиля */}
          {currentView === 'editProfile' && (
            <div className="edit-profile-page">
              <div className="page-header">
                <h2>Редактирование профиля</h2>
                <button onClick={handleBackToMatch} className="back-to-match-btn">
                  ← Вернуться к знакомствам
                </button>
              </div>
              <ProfileForm 
                user={currentUser} 
                onSave={handleSaveProfile} 
                onChangePassword={handleChangePassword} 
              />
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}

export default App;