// Сервис для работы с данными через API (JSON файл на сервере)
const API_URL = 'http://localhost:3001/api';

class ApiService {
  // Вход в систему
  static async login(username, password) {
    try {
      const response = await fetch(`${API_URL}/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password })
      });
      
      const result = await response.json();
      
      if (result.success) {
        return result.user;
      } else {
        throw new Error(result.error || 'Ошибка входа');
      }
    } catch (error) {
      console.error('Ошибка входа:', error);
      throw error;
    }
  }
  
  // Регистрация
  static async register(userData) {
    try {
      const response = await fetch(`${API_URL}/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData)
      });
      
      const result = await response.json();
      
      if (result.success) {
        return result.user;
      } else {
        throw new Error(result.error || 'Ошибка регистрации');
      }
    } catch (error) {
      console.error('Ошибка регистрации:', error);
      throw error;
    }
  }
  
  // Получить текущего пользователя
  static async getCurrentUser() {
    try {
      const response = await fetch(`${API_URL}/current-user`);
      if (!response.ok) {
        throw new Error('Ошибка сети');
      }
      const user = await response.json();
      return user;
    } catch (error) {
      console.error('Ошибка получения текущего пользователя:', error);
      return null;
    }
  }
  
  // Выйти из системы
  static async logout() {
    try {
      const response = await fetch(`${API_URL}/logout`, {
        method: 'POST'
      });
      if (!response.ok) {
        throw new Error('Ошибка сети');
      }
      return true;
    } catch (error) {
      console.error('Ошибка выхода:', error);
      return false;
    }
  }
  
  // Обновить профиль
  static async updateUser(userId, updatedData) {
    try {
      const response = await fetch(`${API_URL}/update-profile/${userId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedData)
      });
      
      const result = await response.json();
      
      if (result.success) {
        return result.user;
      } else {
        throw new Error(result.error || 'Ошибка обновления профиля');
      }
    } catch (error) {
      console.error('Ошибка обновления профиля:', error);
      throw error;
    }
  }
  
  // Сменить пароль
  static async changePassword(userId, currentPassword, newPassword) {
    try {
      const response = await fetch(`${API_URL}/change-password/${userId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ currentPassword, newPassword })
      });
      
      const result = await response.json();
      
      if (result.success) {
        return true;
      } else {
        throw new Error(result.error || 'Ошибка смены пароля');
      }
    } catch (error) {
      console.error('Ошибка смены пароля:', error);
      throw error;
    }
  }
  
  // Получить рекомендации
  static async getRecommendedUsers(userId) {
    try {
      const response = await fetch(`${API_URL}/recommendations/${userId}`);
      if (!response.ok) {
        throw new Error('Ошибка сети');
      }
      const users = await response.json();
      return users;
    } catch (error) {
      console.error('Ошибка получения рекомендаций:', error);
      return [];
    }
  }
  
  // Лайк пользователя
  static async likeUser(currentUserId, targetUserId) {
    try {
      const response = await fetch(`${API_URL}/like/${currentUserId}/${targetUserId}`, {
        method: 'POST'
      });
      
      const result = await response.json();
      
      if (result.success) {
        return true;
      } else {
        throw new Error(result.error || 'Ошибка');
      }
    } catch (error) {
      console.error('Ошибка лайка:', error);
      throw error;
    }
  }
  
  // Дизлайк пользователя
  static async dislikeUser(currentUserId, targetUserId) {
    try {
      const response = await fetch(`${API_URL}/dislike/${currentUserId}/${targetUserId}`, {
        method: 'POST'
      });
      
      const result = await response.json();
      
      if (result.success) {
        return true;
      } else {
        throw new Error(result.error || 'Ошибка');
      }
    } catch (error) {
      console.error('Ошибка дизлайка:', error);
      throw error;
    }
  }
  
  // Получить принятых пользователей
  static async getLikedUsers(userId) {
    try {
      const response = await fetch(`${API_URL}/liked/${userId}`);
      if (!response.ok) {
        throw new Error('Ошибка сети');
      }
      const users = await response.json();
      return users;
    } catch (error) {
      console.error('Ошибка получения принятых пользователей:', error);
      return [];
    }
  }
  
  // Получить отклоненных пользователей
  static async getDislikedUsers(userId) {
    try {
      const response = await fetch(`${API_URL}/disliked/${userId}`);
      if (!response.ok) {
        throw new Error('Ошибка сети');
      }
      const users = await response.json();
      return users;
    } catch (error) {
      console.error('Ошибка получения отклоненных пользователей:', error);
      return [];
    }
  }
  
  // Получить матчи
  static async getMatches(userId) {
    try {
      const response = await fetch(`${API_URL}/matches/${userId}`);
      if (!response.ok) {
        throw new Error('Ошибка сети');
      }
      const users = await response.json();
      return users;
    } catch (error) {
      console.error('Ошибка получения матчей:', error);
      return [];
    }
  }
  
  // Проверка существования пользователя
  static async usernameExists(username) {
    try {
      const response = await fetch(`${API_URL}/data`);
      if (!response.ok) {
        throw new Error('Ошибка сети');
      }
      const data = await response.json();
      return data.users && data.users.some(user => user.username === username);
    } catch (error) {
      console.error('Ошибка проверки логина:', error);
      return false;
    }
  }
  
  // Проверка существования email
  static async emailExists(email) {
    try {
      const response = await fetch(`${API_URL}/data`);
      if (!response.ok) {
        throw new Error('Ошибка сети');
      }
      const data = await response.json();
      return data.users && data.users.some(user => 
        user.email.toLowerCase() === email.toLowerCase()
      );
    } catch (error) {
      console.error('Ошибка проверки email:', error);
      return false;
    }
  }
}

export default ApiService;