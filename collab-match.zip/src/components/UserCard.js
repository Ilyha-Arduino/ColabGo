import React, { useState } from 'react';

// Компонент карточки пользователя (как в предложенных друзьях ВК)
function UserCard({ user, onAccept, onReject, showActions = true }) {
  const [isFlipped, setIsFlipped] = useState(false);
  
  // Функция для переворота карточки
  const flipCard = () => {
    setIsFlipped(!isFlipped);
  };
  
  return (
    <div className={`user-card ${isFlipped ? 'flipped' : ''}`}>
      <div className="card-inner">
        {/* Лицевая сторона карточки */}
        <div className="card-front">
          <div className="card-header">
            <h3>{user.fullName}</h3>
            <span className="user-type">{user.userType}</span>
          </div>
          
          <div className="card-body">
            <p className="bio">{user.bio}</p>
            
            <div className="skills">
              <h4>Навыки:</h4>
              <div className="skills-list">
                {user.skills && user.skills.map((skill, index) => (
                  <span key={index} className="skill-tag">{skill}</span>
                ))}
              </div>
            </div>
            
            <div className="interests">
              <h4>Ищет для коллаборации:</h4>
              <p>{user.interests && user.interests.length > 0 ? user.interests.join(', ') : 'Не указано'}</p>
            </div>
          </div>
          
          <div className="card-footer">
            <button className="flip-btn" onClick={flipCard}>Подробнее</button>
          </div>
        </div>
        
        {/* Оборотная сторона карточки */}
        <div className="card-back">
          <div className="card-header">
            <h3>Контактная информация</h3>
          </div>
          
          <div className="card-body">
            <div className="contact-info">
              <p><strong>Email:</strong> {user.email}</p>
              <p><strong>Логин:</strong> {user.username}</p>
              <p><strong>Специализация:</strong> {user.userType}</p>
              <p><strong>ID:</strong> {user.id}</p>
            </div>
            
            <div className="match-info">
              <h4>Почему мы рекомендуем этого пользователя:</h4>
              <ul>
                <li>Совпадают интересы для коллаборации</li>
                <li>Дополняющие навыки для совместных проектов</li>
                <li>Активный участник сообщества</li>
              </ul>
            </div>
          </div>
          
          <div className="card-footer">
            <button className="flip-btn" onClick={flipCard}>Назад</button>
          </div>
        </div>
        
        {/* Кнопки принятия/отклонения (только если showActions=true) */}
        {showActions && (
          <div className="action-buttons">
            <button className="reject-btn" onClick={() => onReject(user.id)}>
              <span>✕</span> Отклонить
            </button>
            <button className="accept-btn" onClick={() => onAccept(user.id)}>
              <span>✓</span> Принять
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default UserCard;