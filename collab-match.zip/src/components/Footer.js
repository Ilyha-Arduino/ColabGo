import React from 'react';

// Компонент подвала приложения
function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <p>CollabMatch © 2023, "Взрывные котята" Объединяем таланты для создания крутых проектов!</p>
        <p className="footer-note">Make code, not war ☮️</p>
      </div>
    </footer>
  );
}

export default Footer;