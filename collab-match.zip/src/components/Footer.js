import React from 'react';

// Компонент подвала приложения
function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <p>CollabMatch © 2023. Объединяем таланты для создания крутых проектов!</p>
        <p className="footer-note">Для образовательных учреждений: школ, технопарков, кружков, вузов</p>
      </div>
    </footer>
  );
}

export default Footer;