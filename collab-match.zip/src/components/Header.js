import React from 'react';

// Компонент шапки приложения
function Header({ currentUser, onLogout }) {
  return (
    <header className="header">
      <div className="container">
        <h1>CollabGo</h1>
        <p className="tagline">Найди команду для своих проектов</p>
        
        {/* Если пользователь авторизован, показываем его имя и кнопку выхода */}
        {currentUser && (
          <div className="user-info">
            <span>Привет, {currentUser.fullName}!</span>
            <button onClick={onLogout} className="logout-btn">Выйти</button>
          </div>
        )}
      </div>
    </header>
  );
}

export default Header;