import React from 'react';

// Компонент вкладок для переключения между разными разделами
function Tabs({ activeTab, onTabChange }) {
  const tabs = [
    { id: 'match', label: 'Знакомства', icon: '🔍' },
    { id: 'matches', label: 'Матчи', icon: '🤝' },
    { id: 'liked', label: 'Принятые', icon: '❤️' },
    { id: 'disliked', label: 'Отклоненные', icon: '✕' }
  ];
  
  return (
    <div className="tabs-container">
      <div className="tabs">
        {tabs.map(tab => (
          <button
            key={tab.id}
            className={`tab-btn ${activeTab === tab.id ? 'active' : ''}`}
            onClick={() => onTabChange(tab.id)}
          >
            <span className="tab-icon">{tab.icon}</span>
            <span className="tab-label">{tab.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

export default Tabs;