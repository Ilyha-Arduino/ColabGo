import React, { useState, useEffect } from 'react';

// Компонент формы редактирования профиля
function ProfileForm({ user, onSave, onChangePassword }) {
  // Список доступных специализаций
  const userTypes = ['Программист', 'Дизайнер', 'Маркетолог', 'Менеджер', 'Инженер', 'Математик', 'Аналитик', 'Другое'];
  
  // Состояние формы
  const [formData, setFormData] = useState({
    fullName: '',
    userType: '',
    interests: [],
    bio: '',
    skills: []
  });
  
  // Состояние для смены пароля
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  
  // Состояние для нового навыка
  const [newSkill, setNewSkill] = useState('');
  
  // Заполняем форму данными пользователя при загрузке
  useEffect(() => {
    if (user) {
      setFormData({
        fullName: user.fullName || '',
        userType: user.userType || '',
        interests: user.interests || [],
        bio: user.bio || '',
        skills: user.skills || []
      });
    }
  }, [user]);
  
  // Обработчик изменения полей формы
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  // Обработчик изменения полей пароля
  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    setPasswordData({
      ...passwordData,
      [name]: value
    });
  };
  
  // Обработчик изменения интересов (чекбоксы)
  const handleInterestChange = (interest) => {
    const newInterests = formData.interests.includes(interest)
      ? formData.interests.filter(i => i !== interest)
      : [...formData.interests, interest];
    
    setFormData({
      ...formData,
      interests: newInterests
    });
  };
  
  // Добавление нового навыка
  const addSkill = () => {
    if (newSkill.trim() && !formData.skills.includes(newSkill.trim())) {
      setFormData({
        ...formData,
        skills: [...formData.skills, newSkill.trim()]
      });
      setNewSkill('');
    }
  };
  
  // Удаление навыка
  const removeSkill = (skillToRemove) => {
    setFormData({
      ...formData,
      skills: formData.skills.filter(skill => skill !== skillToRemove)
    });
  };
  
  // Обработчик отправки формы профиля
  const handleProfileSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };
  
  // Обработчик смены пароля
  const handlePasswordSubmit = (e) => {
    e.preventDefault();
    
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      alert('Новые пароли не совпадают!');
      return;
    }
    
    onChangePassword(passwordData.currentPassword, passwordData.newPassword);
    
    // Очищаем поля пароля
    setPasswordData({
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    });
  };
  
  return (
    <div className="profile-form">
      <h2>Редактирование профиля</h2>
      
      <form onSubmit={handleProfileSubmit}>
        <div className="form-group">
          <label htmlFor="fullName">Полное имя:</label>
          <input
            type="text"
            id="fullName"
            name="fullName"
            value={formData.fullName}
            onChange={handleChange}
            required
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="userType">Ваша специализация:</label>
          <select
            id="userType"
            name="userType"
            value={formData.userType}
            onChange={handleChange}
            required
          >
            <option value="">Выберите специализацию</option>
            {userTypes.map((type, index) => (
              <option key={index} value={type}>{type}</option>
            ))}
          </select>
        </div>
        
        <div className="form-group">
          <label>Кого вы ищете для коллаборации:</label>
          <div className="interests-list">
            {userTypes.map((type, index) => (
              <div key={index} className="checkbox-item">
                <input
                  type="checkbox"
                  id={`interest-${index}`}
                  checked={formData.interests.includes(type)}
                  onChange={() => handleInterestChange(type)}
                />
                <label htmlFor={`interest-${index}`}>{type}</label>
              </div>
            ))}
          </div>
        </div>
        
        <div className="form-group">
          <label htmlFor="bio">О себе:</label>
          <textarea
            id="bio"
            name="bio"
            value={formData.bio}
            onChange={handleChange}
            rows="4"
            placeholder="Расскажите о себе, своих проектах и чем хотите заниматься..."
          />
        </div>
        
        <div className="form-group">
          <label>Ваши навыки:</label>
          <div className="skills-input">
            <input
              type="text"
              value={newSkill}
              onChange={(e) => setNewSkill(e.target.value)}
              placeholder="Добавьте навык"
            />
            <button type="button" onClick={addSkill} className="add-skill-btn">
              Добавить
            </button>
          </div>
          
          <div className="skills-list">
            {formData.skills.map((skill, index) => (
              <div key={index} className="skill-item">
                <span>{skill}</span>
                <button type="button" onClick={() => removeSkill(skill)} className="remove-skill">
                  ✕
                </button>
              </div>
            ))}
          </div>
        </div>
        
        <button type="submit" className="submit-btn">Сохранить профиль</button>
      </form>
      
      <div className="password-section">
        <h3>Смена пароля</h3>
        <form onSubmit={handlePasswordSubmit}>
          <div className="form-group">
            <label htmlFor="currentPassword">Текущий пароль:</label>
            <input
              type="password"
              id="currentPassword"
              name="currentPassword"
              value={passwordData.currentPassword}
              onChange={handlePasswordChange}
              required
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="newPassword">Новый пароль:</label>
            <input
              type="password"
              id="newPassword"
              name="newPassword"
              value={passwordData.newPassword}
              onChange={handlePasswordChange}
              required
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="confirmPassword">Подтвердите новый пароль:</label>
            <input
              type="password"
              id="confirmPassword"
              name="confirmPassword"
              value={passwordData.confirmPassword}
              onChange={handlePasswordChange}
              required
            />
          </div>
          
          <button type="submit" className="submit-btn">Сменить пароль</button>
        </form>
      </div>
    </div>
  );
}

export default ProfileForm;