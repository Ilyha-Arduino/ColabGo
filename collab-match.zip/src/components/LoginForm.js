import React, { useState } from 'react';

// Компонент формы входа и регистрации
function LoginForm({ onLogin, onRegister, error }) {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    email: '',
    fullName: ''
  });
  
  // Обработчик изменения полей формы
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  // Обработчик отправки формы
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Валидация формы
    if (!isLogin) {
      // Проверка email при регистрации
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        alert('Пожалуйста, введите корректный email адрес');
        return;
      }
      
      // Проверка пароля (минимум 6 символов)
      if (formData.password.length < 6) {
        alert('Пароль должен содержать минимум 6 символов');
        return;
      }
    }
    
    if (isLogin) {
      // Вход
      onLogin(formData.username, formData.password);
    } else {
      // Регистрация
      onRegister(formData);
    }
  };
  
  // Переключение между входом и регистрацией
  const toggleMode = () => {
    setIsLogin(!isLogin);
    setFormData({
      username: '',
      password: '',
      email: '',
      fullName: ''
    });
  };
  
  return (
    <div className="login-form">
      <h2>{isLogin ? 'Вход в систему' : 'Регистрация'}</h2>
      
      {error && <div className="error-message">{error}</div>}
      
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="username">Логин:</label>
          <input
            type="text"
            id="username"
            name="username"
            value={formData.username}
            onChange={handleChange}
            required
            placeholder="Введите ваш логин"
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="password">Пароль:</label>
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
            placeholder="Введите ваш пароль"
          />
          {!isLogin && (
            <small className="password-hint">Пароль должен содержать минимум 6 символов</small>
          )}
        </div>
        
        {!isLogin && (
          <>
            <div className="form-group">
              <label htmlFor="email">Email:</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                placeholder="example@mail.com"
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="fullName">Полное имя:</label>
              <input
                type="text"
                id="fullName"
                name="fullName"
                value={formData.fullName}
                onChange={handleChange}
                required
                placeholder="Иванов Иван Иванович"
              />
            </div>
          </>
        )}
        
        <button type="submit" className="submit-btn">
          {isLogin ? 'Войти' : 'Зарегистрироваться'}
        </button>
      </form>
      
      <div className="toggle-mode">
        <p>
          {isLogin ? 'Нет аккаунта?' : 'Уже есть аккаунт?'}
          <button type="button" onClick={toggleMode} className="toggle-btn">
            {isLogin ? 'Зарегистрироваться' : 'Войти'}
          </button>
        </p>
      </div>
    </div>
  );
}

export default LoginForm;